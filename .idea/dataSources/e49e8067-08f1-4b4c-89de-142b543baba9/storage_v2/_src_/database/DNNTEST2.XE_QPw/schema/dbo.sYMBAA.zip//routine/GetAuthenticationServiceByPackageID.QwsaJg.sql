CREATE PROCEDURE dbo.[GetAuthenticationServiceByPackageID]

	@PackageID int

AS
	SELECT *
		FROM  dbo.Authentication
		WHERE PackageID = @PackageID
go

