CREATE PROCEDURE dbo.[DeleteDesktopModulePermission]
	@DesktopModulePermissionID int
AS
    DELETE FROM dbo.DesktopModulePermission
    WHERE DesktopModulePermissionID = @DesktopModulePermissionID
go

