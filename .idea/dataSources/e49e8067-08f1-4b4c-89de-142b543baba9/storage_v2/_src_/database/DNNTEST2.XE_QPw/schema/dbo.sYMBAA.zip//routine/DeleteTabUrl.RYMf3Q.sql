CREATE PROCEDURE dbo.[DeleteTabUrl] 
	@TabID				int,
	@SeqNum				int
AS
	DELETE FROM dbo.TabUrls
	WHERE TabId = @TabID AND SeqNum = @SeqNum
go

