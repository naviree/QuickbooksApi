CREATE PROCEDURE dbo.[CoreMessaging_GetSubscriptionTypes]
AS 
	SELECT  *
	FROM    dbo.CoreMessaging_SubscriptionTypes
go

