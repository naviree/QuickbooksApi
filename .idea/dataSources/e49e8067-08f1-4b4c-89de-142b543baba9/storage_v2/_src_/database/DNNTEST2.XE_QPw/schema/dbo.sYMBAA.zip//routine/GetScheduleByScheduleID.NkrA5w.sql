CREATE PROCEDURE dbo.[GetScheduleByScheduleID]
@ScheduleID int
AS
SELECT S.*
FROM dbo.Schedule S
WHERE S.ScheduleID = @ScheduleID
go

