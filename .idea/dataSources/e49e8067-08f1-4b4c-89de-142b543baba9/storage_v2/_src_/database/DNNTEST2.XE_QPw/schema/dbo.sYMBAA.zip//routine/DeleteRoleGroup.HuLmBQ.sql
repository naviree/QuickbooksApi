CREATE PROCEDURE dbo.[DeleteRoleGroup]

	@RoleGroupId      int
	
AS

DELETE  
FROM dbo.RoleGroups
WHERE  RoleGroupId = @RoleGroupId
go

