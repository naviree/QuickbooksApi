
CREATE view [dbo].[vw_JNGrease_Locations] as
	SELECT
		L.LocationId
		,L.QbCustomerId
		,L.RouteNumber
		,Q.CustomerName QBCustomerName
		,L.LocationName
		,L.LocationAddress1
		,L.LocationAddress2
		,L.LocationCity
		,L.LocationState
		,L.LocationZip
		,L.LocationEmail
		,L.LocationPhone
		,L.LocationFax
		,L.RouteNumberFat
		,L.RouteNumberOil
		,L.QbCreateDate
		,L.QbLastModifyDate
		,L.DnnUserId CreatedByUserId
		,LC.Username CreatedByUserName
		,L.CreateDate
		,L.LastModifyDate
		,L.LastModifyUserId
		,LU.Username LastModifiedUserName
		,L.LocationMemo
		,L.AutoIncludeManifest
		,L.AssignedDriverId
		,L.OutstandingBalance
		,L.OutstandingInvoiceCount
		,L.MaxInvoiceAging
		,D.DriverFirstName + ' ' + D.DriverLastName AssignedDriverName
		,L.LocationMobilePhone
		,L.LocationContact
		,L.LocationCounty
		,CONCAT(L.LocationAddress1, L.LocationName) LocationSearch
	FROM JNGrease_Locations L (NOLOCK)
	LEFT JOIN JNGrease_QuickBooksCustomers Q (NOLOCK)
		on L.QbCustomerId = Q.CustomerId 
	LEFT JOIN JNGrease_Drivers D (NOLOCK)
		on L.AssignedDriverId = D.DriverId
	LEFT JOIN Users LU (NOLOCK)
		on L.LastModifyUserId = LU.UserID
	LEFT JOIN Users LC (NOLOCK)
		on L.DnnUserId = LC.UserID
go

