CREATE PROCEDURE dbo.[AddContentType] 
	@ContentType	nvarchar(250)
AS
	INSERT INTO dbo.ContentTypes (
		ContentType
	)

	VALUES (
		@ContentType
	)

	SELECT SCOPE_IDENTITY()
go

