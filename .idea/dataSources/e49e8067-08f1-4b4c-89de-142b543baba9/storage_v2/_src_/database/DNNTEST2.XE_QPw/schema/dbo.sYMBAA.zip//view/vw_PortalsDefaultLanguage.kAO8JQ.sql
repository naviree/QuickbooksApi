CREATE VIEW dbo.[vw_PortalsDefaultLanguage]
AS
    SELECT * FROM dbo.[vw_Portals] WHERE CultureCode = DefaultLanguage
go

