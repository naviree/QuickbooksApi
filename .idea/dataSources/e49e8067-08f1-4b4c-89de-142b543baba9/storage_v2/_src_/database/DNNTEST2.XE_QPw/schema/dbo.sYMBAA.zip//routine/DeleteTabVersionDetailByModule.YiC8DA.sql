CREATE PROCEDURE dbo.[DeleteTabVersionDetailByModule]
	@ModuleId   INT
AS
DELETE FROM   dbo.TabVersionDetails
WHERE  ModuleId = @ModuleId
go

