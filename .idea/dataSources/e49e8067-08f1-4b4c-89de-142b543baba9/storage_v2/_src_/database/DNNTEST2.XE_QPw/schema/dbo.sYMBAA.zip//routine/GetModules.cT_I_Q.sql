CREATE PROCEDURE dbo.[GetModules]

	@PortalID int
	
AS
SELECT	* 
FROM dbo.vw_Modules
WHERE  PortalId = @PortalID
ORDER BY ModuleId
go

