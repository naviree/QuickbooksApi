CREATE PROCEDURE dbo.[GetSkinControls]
AS
    SELECT *
    FROM   dbo.SkinControls
	ORDER BY  ControlKey
go

