CREATE PROCEDURE dbo.[GetTabPermission]

	@TabPermissionID int

AS
SELECT *
FROM dbo.vw_TabPermissions
WHERE TabPermissionID = @TabPermissionID
go

