CREATE PROCEDURE dbo.[GetDesktopModulePermission]
	@DesktopModulePermissionID	int
AS
    SELECT *
    FROM dbo.vw_DesktopModulePermissions
    WHERE DesktopModulePermissionID = @DesktopModulePermissionID
go

