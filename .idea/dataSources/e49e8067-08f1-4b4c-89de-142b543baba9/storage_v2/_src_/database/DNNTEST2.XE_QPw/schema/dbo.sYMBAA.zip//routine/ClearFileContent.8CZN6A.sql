CREATE PROCEDURE dbo.[ClearFileContent]

	@FileId      int

AS

UPDATE dbo.Files
	SET    Content = NULL
	WHERE  FileId = @FileId
go

