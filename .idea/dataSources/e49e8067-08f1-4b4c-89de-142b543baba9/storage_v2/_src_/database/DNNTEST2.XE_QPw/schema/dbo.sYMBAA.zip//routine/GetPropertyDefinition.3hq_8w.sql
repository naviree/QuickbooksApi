CREATE PROCEDURE dbo.[GetPropertyDefinition]

	@PropertyDefinitionID	int

AS
SELECT	dbo.ProfilePropertyDefinition.*
FROM	dbo.ProfilePropertyDefinition
WHERE PropertyDefinitionID = @PropertyDefinitionID
	AND Deleted = 0
go

