CREATE PROCEDURE dbo.[UpdateFolderVersion]
	@FolderID		int,
    @VersionGuid	uniqueidentifier
AS
    UPDATE dbo.Folders
        SET    VersionGuid = @VersionGuid
    WHERE  FolderID = @FolderID
go

