CREATE PROCEDURE dbo.[UpdatePortalDefaultLanguage]

	@PortalId            int,
	@CultureCode   nvarchar(50)
AS
	UPDATE dbo.Portals
		SET defaultlanguage=@CultureCode
		where portalid=@PortalId
go

