CREATE PROCEDURE dbo.[GetPackageDependencies]
AS
	SELECT * FROM dbo.[PackageDependencies]
go

