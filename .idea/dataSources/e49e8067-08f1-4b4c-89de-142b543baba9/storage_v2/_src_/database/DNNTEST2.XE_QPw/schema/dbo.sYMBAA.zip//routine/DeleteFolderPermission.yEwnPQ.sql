CREATE PROCEDURE dbo.[DeleteFolderPermission]
	@FolderPermissionID int
AS

DELETE FROM dbo.FolderPermission
WHERE
	[FolderPermissionID] = @FolderPermissionID
go

