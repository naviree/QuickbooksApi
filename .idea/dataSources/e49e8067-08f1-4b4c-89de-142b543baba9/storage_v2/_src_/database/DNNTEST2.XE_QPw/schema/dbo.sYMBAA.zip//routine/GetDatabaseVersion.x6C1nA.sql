create procedure dbo.[GetDatabaseVersion]

as

select Major,
       Minor,
       Build
from   dbo.Version 
where  VersionId = ( select max(VersionId) from dbo.Version )
go

