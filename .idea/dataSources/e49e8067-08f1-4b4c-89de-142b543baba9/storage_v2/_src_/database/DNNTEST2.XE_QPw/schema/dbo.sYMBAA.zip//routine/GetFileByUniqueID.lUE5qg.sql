CREATE PROCEDURE dbo.[GetFileByUniqueID]
    @UniqueID   uniqueidentifier
AS
	SELECT	* 
	FROM	dbo.Files
	WHERE	UniqueID = @UniqueID
go

