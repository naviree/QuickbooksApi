CREATE PROCEDURE dbo.[DeleteRelationship] @RelationshipID INT	
AS 
	BEGIN
		DELETE FROM dbo.Relationships  
			WHERE RelationshipID = @RelationshipID
	END
go

