CREATE function dbo.[PhoneP]
		(
		@PNum as NVARCHAR(4000)
		)
		returns NVARCHAR(4000)
	AS
	BEGIN
		Declare @Text NVARCHAR (4000)
		Declare @Suff NVARCHAR (255)
	
		SET @Text = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@PNum,'(',''),')',''),'-',''),' ',''),'.',''),'\',''),'/','')
	
	
		--Strip out Fax
		IF CHARINDEX('f',@Text) > 0 
			Begin
				Set @Suff = ' Fax'
				Set @Text=Replace(@Text,'officefax','')
				Set @Text=Replace(@Text,'office fax','')
				Set @Text=Replace(@Text,'fax:','')
				Set @Text=Replace(@Text,'fax','')
				Set @Text=Replace(@Text,'fx:','')
				Set @Text=Replace(@Text,'fx','')		
				Set @Text=Replace(@Text,'f:','')
				Set @Text=Replace(@Text,'f','')		
			End
	
		--Strip out Cell
		IF CHARINDEX('c',@Text) > 0 
			Begin
				Set @Suff = ' Cell'
				Set @Text=Replace(@Text,'cellphone','')
				Set @Text=Replace(@Text,'cell phone','')
				Set @Text=Replace(@Text,'cell:','')
				Set @Text=Replace(@Text,'cell','')
				Set @Text=Replace(@Text,'c:','')	
				Set @Text=Replace(@Text,'c','')
			End
	
		--Strip out Pager
		IF CHARINDEX('p',@Text) > 0 
			or CHARINDEX('pager',@Text) > 0
			Begin
				Set @Suff = ' Pager'
				Set @Text=Replace(@Text,'pager:','')
				Set @Text=Replace(@Text,'pager','')
				Set @Text=Replace(@Text,'pgr:','')
				Set @Text=Replace(@Text,'pgr','')
				Set @Text=Replace(@Text,'pg:','')
				Set @Text=Replace(@Text,'p:','')
				Set @Text=Replace(@Text,'p','')
			End
	
		--Strip out Backline
		IF CHARINDEX('b',@Text) > 0 
			Begin
				Set @Suff = ' Backline'
				Set @Text=Replace(@Text,'bakline','')		--Backline was chaged to bakline due to the4 "C" being removed as part of the cellphone cleanup
				Set @Text=Replace(@Text,'bak line','')
				Set @Text=Replace(@Text,'baklin','')
				Set @Text=Replace(@Text,'b:','')
				Set @Text=Replace(@Text,'b','')
			End
		
		--Strip out home
		IF CHARINDEX('h',@Text) > 0 
			or CHARINDEX('home',@Text) > 0
			or CHARINDEX('hm',@Text) > 0
			Begin
				Set @Suff = ' Home'
				Set @Text=Replace(@Text,'home phone','')
				Set @Text=Replace(@Text,'homephone','')
				Set @Text=Replace(@Text,'home','')
				Set @Text=Replace(@Text,'hm','')
				Set @Text=Replace(@Text,'h','')
			End
		
		-- Check for length 7 or 10 with no leading 1 or 0
		IF LEN(@Text) in (7,10) and ISNUMERIC(@Text)=1
			SET @PNum=@Text
		
		--Check for a length of 11 with a leading 1 or 0
		IF LEN(@Text) = 11 and left(@Text,1) in ('0','1') and ISNUMERIC(@Text)=1
			SET @PNum=@Text
	
		IF @PNum=@Text and ISNUMERIC(@Text)=1
			BEGIN
				--Strip off leading 0 or 1
				IF LEFT(@PNum,1) in ('0','1')
					Set @PNum = RIGHT(@PNum,len(@PNum)-1)
			
				--Reformat phone number
				Set @PNum = Case 
								When LEN(@PNum) = 7
									Then LEFT(@PNum,3) + '-' + RIGHT(@PNum,4) + ISNULL(@Suff,'')
								When LEN(@PNum) = 10
									THEN '(' + LEFT(@PNum,3) + ') ' + SUBSTRING(@PNum,4,3) + '-' + RIGHT(@PNum,4) + ISNULL(@Suff,'')
								Else @PNum
							End					
			END
		
		IF @PNum!=@Text and ISNUMERIC(Left(@Text,10))=1 and len(Left(@Text,10))=10
			BEGIN
				--Reformat phone number
				Set @PNum=@Text
				Set @PNum='(' + LEFT(@PNum,3) + ') ' + SUBSTRING(@PNum,4,3) + '-' + SUBSTRING(@PNum,7,4) + ' ' + right(@Pnum,len(@PNum)-10)
			END 

		If LTRIM(RTRIM(@PNum)) in ('none','none listed','')
			Begin
				Set @PNum = NULL
			End
		
	   return @PNum
	END
go

