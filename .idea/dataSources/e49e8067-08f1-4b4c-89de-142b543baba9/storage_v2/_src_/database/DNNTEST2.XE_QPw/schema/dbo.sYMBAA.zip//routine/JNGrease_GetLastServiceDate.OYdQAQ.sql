


CREATE FUNCTION [dbo].[JNGrease_GetLastServiceDate]
(
	@ScheduleId Int
)
RETURNS DATETIME
AS
BEGIN

	DECLARE @LastServiceDate DATETIME

	SELECT @LastServiceDate = 
		
		MAX(ServiceStartDate)
			FROM
				(
				Select --Pick start date from Service Schedule if work order has never been created
					ServiceStartDate
				FROM JNGrease_ServiceSchedule
				where ScheduleId = @ScheduleId
				AND ScheduleID NOT IN (select ServiceScheduleId from JNGrease_WorkOrders where ServiceScheduleId = @ScheduleId)
				AND ServiceStartDate IS NOT NULL
				UNION
				SELECT --Pick start date from work orders that only have been invoiced
					WO.ServiceDate ServiceStartDate
				FROM JNGrease_WorkOrders WO
				JOIN JNGrease_ServiceSchedule SS
					ON SS.ScheduleId = WO.ServiceScheduleId
				where WO.ServiceScheduleId = @ScheduleId
				AND ServiceScheduleId NOT IN 
					(
						select TOP (100) PERCENT ServiceScheduleId 
						from JNGrease_WorkOrders WO 
						LEFT JOIN JNGrease_QuickBooksInvoices Q
							ON WO.WorkOrderId = Q.WorkOrder
						where  Q.InvoiceNumber is null 
							and WO.ServiceScheduleId = @ScheduleId
							and ServiceScheduleId is not null
						order by 1
					)
				/***removing for now was put in place previously to avoid orders created within 1 minute of each other***/
				--OR 
				--	ServiceScheduleId = @ScheduleId
				--AND ServiceScheduleId NOT IN 

				--	(
				--		select 
				--			ServiceScheduleId
				--		from vw_JNGrease_WorkOrders WO
				--		JOIN
				--			(
				--			select
				--				WorkOrderId
				--				,QbInvoiceNumber
				--				,WorkOrderCreateDate
				--				,ROW_NUMBER()OVER(PARTITION BY LocationID order by WorkOrderCreateDate desc) row_num
				--			from vw_JNGrease_WorkOrders
				--			) DT_WO
				--			on WO.WorkOrderId = DT_WO.WorkOrderId
				--			and DT_WO.row_num = 1
				--		where 
				--		WO.ServiceScheduleId = @ScheduleId
				--		and WO.QbInvoiceNumber is null
				--		and DATEDIFF(MI,DT_WO.WorkOrderCreateDate, GETDATE()) <= 1
				--	)
				) A

	RETURN @LastServiceDate

END
go

