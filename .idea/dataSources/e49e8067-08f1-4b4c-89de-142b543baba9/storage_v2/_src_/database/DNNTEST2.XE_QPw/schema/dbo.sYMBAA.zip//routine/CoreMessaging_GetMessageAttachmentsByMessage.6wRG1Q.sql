CREATE PROCEDURE dbo.[CoreMessaging_GetMessageAttachmentsByMessage]
    @MessageID INT
AS
	SELECT [MessageID], [FileID], [CreatedByUserID], [CreatedOnDate], [LastModifiedByUserID], [LastModifiedOnDate]
	FROM   dbo.CoreMessaging_MessageAttachments
	WHERE  [MessageID] = @MessageID
go

