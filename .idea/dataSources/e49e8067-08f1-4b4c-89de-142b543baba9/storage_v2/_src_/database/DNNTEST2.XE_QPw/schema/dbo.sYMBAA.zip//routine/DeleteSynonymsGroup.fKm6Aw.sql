CREATE PROCEDURE dbo.[DeleteSynonymsGroup]
	@SynonymsGroupID int
AS
BEGIN	
	DELETE FROM dbo.SynonymsGroups WHERE SynonymsGroupID = @SynonymsGroupID
END
go

