CREATE PROCEDURE dbo.[UpdateContentType] 
	@ContentTypeId		int,
	@ContentType		nvarchar(250)
AS
	UPDATE dbo.ContentTypes 
		SET 
			ContentType = @ContentType
	WHERE ContentTypeId = @ContentTypeId
go

