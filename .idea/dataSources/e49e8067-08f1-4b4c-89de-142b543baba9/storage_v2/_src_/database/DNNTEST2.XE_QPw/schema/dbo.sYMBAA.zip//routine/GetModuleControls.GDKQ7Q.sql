CREATE PROCEDURE dbo.[GetModuleControls]
AS
    SELECT *
    FROM   dbo.ModuleControls
	ORDER BY  ControlKey, ViewOrder
go

