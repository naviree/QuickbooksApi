CREATE PROCEDURE dbo.[GetFolderMappingsSetting]
	@FolderMappingID int,
	@SettingName nvarchar(50)
AS
BEGIN
	SELECT *
	FROM dbo.[FolderMappingsSettings]
	WHERE FolderMappingID = @FolderMappingID AND SettingName = @SettingName
END
go

