CREATE PROCEDURE dbo.[SearchDeletedItems_Select]
    @CutoffTime	DATETIME
AS
BEGIN
	SELECT document
	FROM dbo.SearchDeletedItems
	WHERE [DateCreated] < @CutoffTime
	ORDER BY [DateCreated]
END
go

