CREATE PROCEDURE dbo.[GetRelationship] @RelationshipID INT
AS 
    SELECT  RelationshipID,
            RelationshipTypeID,            
            Name,            
            Description,
            UserID,
            PortalID,
            DefaultResponse,
            CreatedByUserID ,
            CreatedOnDate ,
            LastModifiedByUserID ,
            LastModifiedOnDate
    FROM    dbo.Relationships    
	WHERE RelationshipID = @RelationshipID
	ORDER BY RelationshipID ASC
go

