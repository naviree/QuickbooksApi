CREATE PROCEDURE dbo.[OutputCachePurgeExpiredItems]
	@CurrentUtcDateTime DateTime
AS
BEGIN
    DELETE
     FROM  dbo.OutputCache
     WHERE Expiration <= @CurrentUtcDateTime
END
go

