create procedure dbo.[GetUrls]

@PortalID     int

as

select *
from   dbo.Urls
where  PortalID = @PortalID
order by Url
go

