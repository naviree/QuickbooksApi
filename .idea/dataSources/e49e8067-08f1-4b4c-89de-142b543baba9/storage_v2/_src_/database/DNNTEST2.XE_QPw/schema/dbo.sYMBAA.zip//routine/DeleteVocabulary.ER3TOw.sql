CREATE PROCEDURE dbo.[DeleteVocabulary] 
	@VocabularyID			int
AS
	DELETE FROM dbo.Taxonomy_Vocabularies
	WHERE VocabularyID = @VocabularyID
go

