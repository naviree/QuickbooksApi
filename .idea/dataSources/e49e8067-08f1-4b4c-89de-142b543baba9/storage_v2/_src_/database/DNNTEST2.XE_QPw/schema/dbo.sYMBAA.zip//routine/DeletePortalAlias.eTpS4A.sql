CREATE procedure dbo.[DeletePortalAlias]
@PortalAliasID int

as

DELETE FROM dbo.PortalAlias 
WHERE PortalAliasID = @PortalAliasID
go

