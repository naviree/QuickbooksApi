CREATE PROCEDURE dbo.[DeleteSkinPackage]

	@SkinPackageID		int

AS
    DELETE
	    FROM	dbo.SkinPackages
	WHERE   SkinPackageID = @SkinPackageID
go

