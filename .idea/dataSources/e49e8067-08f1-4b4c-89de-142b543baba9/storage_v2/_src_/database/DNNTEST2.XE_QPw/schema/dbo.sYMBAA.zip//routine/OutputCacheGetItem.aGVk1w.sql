CREATE PROCEDURE dbo.[OutputCacheGetItem]
	@CacheKey VarChar (36)
AS
BEGIN
    SELECT *
     FROM  dbo.OutputCache
     WHERE CacheKey = @CacheKey
END
go

