CREATE PROCEDURE [dbo].[JNGrease_GetBatchWorkOrders]
		@StartDate datetime, 
		@EndDate datetime
	AS
	BEGIN

		SET NOCOUNT ON;

		SELECT
			l.LocationId
			,ss.ServiceId [ServicePerformedId]
			,l.AssignedDriverId [DriverPerformedId]
			,sd.ServiceStartDate [ServiceDate]
			,ss.ServiceCost [ExpectedCost]
			,ss.ServiceVolume [ExpectedVolume]
			,ss.ServiceUnitOfMeasure [UnitReceived]
			,ss.ServiceMemo [WorkOrderMemo]
			,ss.IsWasteManifest [IsWorkOrderWasteManifest]
			,ss.IsServiceMemoPublic [IsWorkOrderMemoPublic]
			,ss.TrapCount
			,ss.TrapLocation
			,ss.ServiceHours
			,'Every ' + CAST(ss.ServiceCount as char(2)) + ' ' + ss.ServiceInterval + '(s)' as [ServiceFrequency]
			,ss.OtherDescription
			,ss.ManifestDescription
			,ss.ManifestVolume
			,ss.ManifestNotes
			,ss.DisposalFacilityId
			,ss.WasteHaulerId
			,ss.ScheduleId [ServiceScheduleId]
		FROM dbo.GetServiceDates(@EndDate) sd
		JOIN JNGrease_Locations l
			ON sd.LocationId = l.LocationId
		JOIN JNGrease_ServiceSchedule ss
			ON sd.LocationId = ss.LocationId
			AND sd.ScheduleID = ss.ScheduleId
		JOIN JNGrease_Services s
			on sd.ServiceId = s.ServiceId 
		where sd.ServiceStartDate between @StartDate and @EndDate
		option (maxrecursion 0)
	END

/************************************************************/
/*****              SqlDataProvider                     *****/
/************************************************************/
go

