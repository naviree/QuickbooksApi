create procedure dbo.GetWorkflows
	@PortalID int
as
	select *
	from   dbo.Workflow
	where (PortalID = @PortalID or PortalID is null)
	order by WorkflowName
go

