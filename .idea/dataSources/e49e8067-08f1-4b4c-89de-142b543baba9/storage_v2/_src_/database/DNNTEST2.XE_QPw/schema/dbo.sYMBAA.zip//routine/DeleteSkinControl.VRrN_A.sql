CREATE PROCEDURE dbo.[DeleteSkinControl]
	@SkinControlId int
AS
    DELETE
    FROM   dbo.SkinControls
    WHERE  SkinControlId = @SkinControlId
go

