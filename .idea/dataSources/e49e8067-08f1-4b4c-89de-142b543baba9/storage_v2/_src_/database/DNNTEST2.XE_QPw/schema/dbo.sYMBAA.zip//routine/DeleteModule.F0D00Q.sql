create procedure dbo.[DeleteModule]

@ModuleId   int

as

delete
from   dbo.Modules 
where  ModuleId = @ModuleId
go

