CREATE PROCEDURE dbo.[GetScheduleItemSettings] 
@ScheduleID int
AS
SELECT *
FROM dbo.ScheduleItemSettings
WHERE ScheduleID = @ScheduleID
go

