CREATE PROCEDURE dbo.[DeleteEventLog]	
    @LogGUID varchar(36)
AS
BEGIN
    IF @LogGUID is null
    BEGIN
        DELETE FROM dbo.EventLog
    END ELSE BEGIN
        DELETE FROM dbo.EventLog WHERE LogGUID = @LogGUID
    END
END
go

