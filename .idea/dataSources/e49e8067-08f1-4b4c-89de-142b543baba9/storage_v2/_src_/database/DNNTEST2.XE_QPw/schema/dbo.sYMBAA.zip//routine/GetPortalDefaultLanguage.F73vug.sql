CREATE PROCEDURE dbo.[GetPortalDefaultLanguage]

	@PortalId            int

AS
	SELECT defaultlanguage
		FROM dbo.Portals
		where portalid=@PortalId
go

