CREATE PROCEDURE dbo.[DeleteContentWorkflowLogs]
	@ContentItemID int,
	@WorkflowID int
AS
    DELETE FROM dbo.[ContentWorkflowLogs]
	WHERE ContentItemID = @ContentItemID AND WorkflowID = @WorkflowID

	SELECT @@ROWCOUNT
go

