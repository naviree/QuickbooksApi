create procedure dbo.[DeleteModuleControl]

@ModuleControlId int

as

delete
from   dbo.ModuleControls
where  ModuleControlId = @ModuleControlId
go

