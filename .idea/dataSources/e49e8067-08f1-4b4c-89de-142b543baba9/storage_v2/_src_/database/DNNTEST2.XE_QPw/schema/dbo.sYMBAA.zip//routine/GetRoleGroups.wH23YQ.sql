CREATE PROCEDURE dbo.[GetRoleGroups]
	@PortalID		int
AS
	SELECT *
		FROM dbo.RoleGroups
		WHERE  PortalId = @PortalID
		ORDER BY RoleGroupName
go

