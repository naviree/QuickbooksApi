CREATE PROCEDURE dbo.[GetLanguagePackByPackage]

	@PackageID int

AS
	SELECT * FROM dbo.LanguagePacks 
        WHERE  PackageID = @PackageID
go

