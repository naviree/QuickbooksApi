/************************************************************/
/*****              SqlDataProvider                     *****/
/*****                                                  *****/
/*****                                                  *****/
/***** Note: To manually execute this script you must   *****/
/*****       perform a search and replace operation     *****/
/*****       for dbo. and   *****/
/*****                                                  *****/
/************************************************************/

CREATE FUNCTION dbo.[GetDaysFromService]
	(
		@ServiceCount int
		,@ServiceInterval varchar(20)
	)
	RETURNS decimal(15,2)
	AS
	BEGIN

		DECLARE @Days decimal(15,2)

		SELECT @Days = 	CASE 
							WHEN @ServiceInterval = 'Year' THEN @ServiceCount * 365
							WHEN @ServiceInterval = 'Month' THEN @ServiceCount * 30.5
							WHEN @ServiceInterval = 'Week' THEN 365/(52/@ServiceCount)
							WHEN @ServiceInterval = 'Day' THEN @ServiceCount * 1.00
							ELSE 0.00							
						END
		RETURN @Days

	END
go

