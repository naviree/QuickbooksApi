CREATE PROCEDURE dbo.[DeleteTabVersion]
    @Id INT
AS
BEGIN
    DELETE FROM dbo.[TabVersions] WHERE TabVersionId = @Id
END
go

