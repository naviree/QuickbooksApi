CREATE PROCEDURE dbo.[DeleteScopeType] 
	@ScopeTypeId			int
AS
	DELETE FROM dbo.Taxonomy_ScopeTypes
	WHERE ScopeTypeId = @ScopeTypeId
go

