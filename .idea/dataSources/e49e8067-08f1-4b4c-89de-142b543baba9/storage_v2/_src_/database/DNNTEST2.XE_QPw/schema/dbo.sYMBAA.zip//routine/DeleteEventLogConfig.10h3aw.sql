CREATE PROCEDURE dbo.[DeleteEventLogConfig]
	@ID int
AS
DELETE FROM dbo.EventLogConfig
WHERE ID = @ID
go

