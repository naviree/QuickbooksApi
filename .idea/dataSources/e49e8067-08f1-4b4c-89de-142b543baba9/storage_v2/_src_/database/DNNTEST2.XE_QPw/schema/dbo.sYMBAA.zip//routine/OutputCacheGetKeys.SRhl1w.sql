CREATE PROCEDURE dbo.[OutputCacheGetKeys]
	@ItemId Int
AS
BEGIN
    SELECT CacheKey
     FROM  dbo.OutputCache
     WHERE ItemId = @ItemId OR @ItemId IS NULL
END
go

