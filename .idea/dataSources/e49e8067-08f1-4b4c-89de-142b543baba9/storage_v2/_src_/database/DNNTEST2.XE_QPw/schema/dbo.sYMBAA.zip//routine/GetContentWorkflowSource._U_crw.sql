CREATE PROCEDURE dbo.[GetContentWorkflowSource]
	@WorkflowID INT,
    @SourceName NVARCHAR(20)
AS
    SELECT 
		[SourceID],
		[WorkflowID],
		[SourceName],
		[SourceType]
	FROM dbo.ContentWorkflowSources
    WHERE WorkflowID = @WorkflowID AND SourceName = @SourceName
go

