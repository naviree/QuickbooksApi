CREATE PROCEDURE dbo.[GetAllTabsModulesByModuleID]
    @ModuleID	int
AS
	SELECT	* 
	FROM dbo.vw_Modules
	WHERE  ModuleID = @ModuleID
go

