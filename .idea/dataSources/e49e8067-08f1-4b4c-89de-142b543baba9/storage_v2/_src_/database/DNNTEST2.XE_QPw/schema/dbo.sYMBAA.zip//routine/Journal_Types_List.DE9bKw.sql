CREATE PROCEDURE dbo.[Journal_Types_List]
@PortalId int
AS
SELECT * 
FROM dbo.[Journal_Types]
WHERE (PortalId = -1 OR PortalId = @PortalId)
go

