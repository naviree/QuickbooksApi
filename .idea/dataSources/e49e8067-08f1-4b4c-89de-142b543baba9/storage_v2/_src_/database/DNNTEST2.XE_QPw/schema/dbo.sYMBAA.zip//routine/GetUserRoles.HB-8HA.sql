CREATE PROCEDURE dbo.[GetUserRoles]
	@PortalId  int,
	@UserId    int
AS
	SELECT *
		FROM dbo.vw_UserRoles
		WHERE UserID = @UserId AND PortalID = @PortalId
go

