CREATE PROCEDURE dbo.[GetTabModule]
    @TabModuleID	int
AS
    SELECT *
	FROM dbo.vw_TabModules        
    WHERE  TabModuleID = @TabModuleID
go

