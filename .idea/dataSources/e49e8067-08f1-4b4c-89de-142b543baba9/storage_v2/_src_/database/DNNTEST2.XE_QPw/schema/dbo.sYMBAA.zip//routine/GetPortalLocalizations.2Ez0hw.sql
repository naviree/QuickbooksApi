CREATE PROCEDURE dbo.[GetPortalLocalizations]
    @PortalId			int
AS
	SELECT * FROM dbo.[PortalLocalization] WHERE PortalId = @PortalId
go

