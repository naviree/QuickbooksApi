CREATE PROCEDURE dbo.[GetCustomAliasesForTabs] 
AS
	SELECT HttpAlias
	FROM  dbo.[PortalAlias] pa 
	WHERE PortalAliasId IN (SELECT PortalAliasId FROM dbo.[TabUrls])
	ORDER BY HttpAlias
go

