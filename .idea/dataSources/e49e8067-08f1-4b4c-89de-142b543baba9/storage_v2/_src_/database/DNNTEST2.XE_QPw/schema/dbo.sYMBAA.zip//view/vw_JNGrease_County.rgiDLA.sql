CREATE VIEW dbo.[vw_JNGrease_County] as
SELECT DISTINCT
jl.LocationCounty
from dbo.JNGrease_Locations jl
JOIN dbo.JNGrease_ZIPTOCOUNTY jz
ON left(jl.LocationZip,5) = jz.ZIPCODE
WHERE jl.LocationState = 'CA'
AND jl.LocationCounty IS NOT NULL
go

