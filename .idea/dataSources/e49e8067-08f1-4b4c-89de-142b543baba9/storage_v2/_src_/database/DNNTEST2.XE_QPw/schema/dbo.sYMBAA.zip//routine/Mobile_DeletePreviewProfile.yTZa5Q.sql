CREATE PROCEDURE dbo.[Mobile_DeletePreviewProfile] @Id INT
AS 
		
    DELETE  FROM dbo.Mobile_PreviewProfiles
    WHERE   Id = @Id
go

