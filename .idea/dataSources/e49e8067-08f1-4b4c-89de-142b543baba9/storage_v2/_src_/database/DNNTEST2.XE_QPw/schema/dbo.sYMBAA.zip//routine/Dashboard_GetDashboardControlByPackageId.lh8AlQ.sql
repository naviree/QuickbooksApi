CREATE PROCEDURE dbo.Dashboard_GetDashboardControlByPackageId  
	@PackageID INT
AS
	SELECT *
	  FROM dbo.Dashboard_Controls
		WHERE PackageID = @PackageID AND PackageID <> -1
go

