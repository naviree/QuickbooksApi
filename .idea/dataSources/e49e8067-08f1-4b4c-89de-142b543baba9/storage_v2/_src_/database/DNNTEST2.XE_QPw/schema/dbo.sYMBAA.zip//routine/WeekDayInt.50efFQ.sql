CREATE FUNCTION dbo.[WeekDayInt]
		(
		@DayOfWeek Varchar(10)
		)
	RETURNS INT
				AS
		BEGIN
		DECLARE @iDayofWeek INT
		SELECT @iDayofWeek = CASE @DayOfWeek
						WHEN 'Sunday' THEN 1
						WHEN 'Monday' THEN 2
						WHEN 'Tuesday' THEN 3
						WHEN 'Wednesday' THEN 4
						WHEN 'Thursday' THEN 5
						WHEN 'Friday' THEN 6
						WHEN 'Saturday' THEN 7
			END
		RETURN (@iDayofWeek)
	END

/************************************************************/
/*****              SqlDataProvider                     *****/
/************************************************************/
go

