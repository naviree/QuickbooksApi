CREATE PROCEDURE dbo.[GetPackageTypes]
AS
	SELECT * FROM dbo.PackageTypes
go

