CREATE PROCEDURE dbo.[DeletePackage]
	@PackageID		int
AS
	DELETE 
		FROM   dbo.Packages
		WHERE  [PackageID] = @PackageID
go

