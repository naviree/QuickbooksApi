CREATE PROCEDURE dbo.[DeleteRelationshipType] @RelationshipTypeID INT	
AS 
	BEGIN
		DELETE FROM dbo.RelationshipTypes  
			WHERE RelationshipTypeID = @RelationshipTypeID
	END
go

