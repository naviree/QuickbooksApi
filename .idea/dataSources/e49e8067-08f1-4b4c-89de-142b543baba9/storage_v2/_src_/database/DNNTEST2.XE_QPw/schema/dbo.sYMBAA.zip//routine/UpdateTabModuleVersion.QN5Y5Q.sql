CREATE PROCEDURE dbo.[UpdateTabModuleVersion]
    @TabModuleID	int,
    @VersionGuid	uniqueidentifier
AS
    UPDATE dbo.TabModules
        SET    VersionGuid = @VersionGuid
    WHERE  TabModuleID = @TabModuleID
go

