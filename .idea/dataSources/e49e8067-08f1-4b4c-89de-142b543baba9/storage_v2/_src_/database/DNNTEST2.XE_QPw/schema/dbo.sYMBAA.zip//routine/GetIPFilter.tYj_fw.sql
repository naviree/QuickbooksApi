CREATE PROCEDURE dbo.[GetIPFilter]
@InputFilter int
AS 
	SELECT * FROM dbo.IPFilter where IPFilterID=@InputFilter
go

