CREATE PROCEDURE dbo.[GetSkinControlByPackageID]
	@PackageID	int
AS
    SELECT *
    FROM   dbo.SkinControls
	WHERE PackageID = @PackageID
go

