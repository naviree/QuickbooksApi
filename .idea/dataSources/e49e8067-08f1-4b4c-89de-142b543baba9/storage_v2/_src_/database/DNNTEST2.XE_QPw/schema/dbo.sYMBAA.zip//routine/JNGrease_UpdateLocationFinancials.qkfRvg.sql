CREATE PROCEDURE dbo.[JNGrease_UpdateLocationFinancials] 
		@QbCustomerId varchar(20)
	AS
	BEGIN

		SET NOCOUNT ON;

		UPDATE L
		SET
			OutstandingBalance = ISNULL(BalanceDue,0)
			,OutstandingInvoiceCount = ISNULL(InvoiceCount,0)
			,MaxInvoiceAging = ISNULL(MaxAging,0)
		FROM JNGrease_Locations L
		LEFT JOIN
			(
			select
				QBCustomerId 
				,count(InvoiceNumber) InvoiceCount
				,sum(InvoiceBalance) BalanceDue
				,CASE
					WHEN DATEDIFF(dd,min(QbDueDate),CAST(GETDATE() as date)) <= 0 THEN 0
					ELSE DATEDIFF(dd,min(QbDueDate),CAST(GETDATE() as date))
				END MaxAging
			from JNGrease_QuickBooksInvoices
			--where QBDueDate <= CAST(GETDATE() as date)
			where IsPaid = 0
			group by QBCustomerId
			) I
			ON L.QbCustomerId = I.QBCustomerId
		WHERE L.QbCustomerId = @QbCustomerId

	END
go

