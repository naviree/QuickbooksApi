CREATE FUNCTION [dbo].[CleanA]
(@String NVARCHAR(MAX))
RETURNS NVARCHAR(MAX)
AS
BEGIN
RETURN dbo.Clean(@String, '^a-z')
END
go

