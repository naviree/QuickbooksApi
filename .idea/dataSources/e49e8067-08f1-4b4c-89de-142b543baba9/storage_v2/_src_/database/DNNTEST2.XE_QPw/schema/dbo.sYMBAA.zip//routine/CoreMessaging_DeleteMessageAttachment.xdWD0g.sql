CREATE PROCEDURE dbo.[CoreMessaging_DeleteMessageAttachment]
    @MessageAttachmentID int
AS
	DELETE FROM dbo.CoreMessaging_MessageAttachments
	WHERE  [MessageAttachmentID] = @MessageAttachmentID
go

