CREATE PROCEDURE dbo.[GetSharedModulesByPortal]
	@Portald int
AS
	SELECT * FROM dbo.vw_TabModules tb		
	WHERE tb.PortalID != tb.OwnerPortalID	
	AND tb.OwnerPortalID = @Portald
go

