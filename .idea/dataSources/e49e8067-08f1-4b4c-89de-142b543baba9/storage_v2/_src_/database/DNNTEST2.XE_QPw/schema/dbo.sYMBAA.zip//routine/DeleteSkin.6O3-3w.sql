CREATE PROCEDURE dbo.[DeleteSkin]

	@SkinID		int

AS

DELETE
	FROM	dbo.Skins
	WHERE   SkinID = @SkinID
go

