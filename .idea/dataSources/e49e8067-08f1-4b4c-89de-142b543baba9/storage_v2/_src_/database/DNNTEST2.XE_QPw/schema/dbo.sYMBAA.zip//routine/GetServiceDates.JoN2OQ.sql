CREATE function [dbo].[GetServiceDates]
	(
		@EndDate as datetime
	)
	returns table
	as return

	WITH Dates as
	(
	SELECT
		LocationId
		,ServiceId
		,ScheduleId
		,ServiceInterval
		,ServiceCount
		,dbo.JNGrease_GetLastServiceDate(ScheduleId) ServiceStartDate
		,ServiceUnitOfMeasure
		,ServiceVolume
		,ExcludeDay
	FROM JNGrease_ServiceSchedule
 
	UNION ALL
 
	SELECT 
		LocationId
		,ServiceId
		,ScheduleId
		,ServiceInterval
		,ServiceCount
		,CASE
			WHEN DATENAME(DW,dateadd(day , dbo.GetDaysFromService(ServiceCount, ServiceInterval), ServiceStartDate)) = ExcludeDay
			THEN dateadd(day , dbo.GetDaysFromService(ServiceCount, ServiceInterval), ServiceStartDate) + 1
			ELSE dateadd(day , dbo.GetDaysFromService(ServiceCount, ServiceInterval), ServiceStartDate)
		END AS ServiceStartDate
		,ServiceUnitOfMeasure
		,ServiceVolume
		,ExcludeDay
	FROM Dates
	WHERE dateadd (day, dbo.GetDaysFromService(ServiceCount, ServiceInterval), ServiceStartDate) <= @EndDate
	)

	select *
	from Dates
go

