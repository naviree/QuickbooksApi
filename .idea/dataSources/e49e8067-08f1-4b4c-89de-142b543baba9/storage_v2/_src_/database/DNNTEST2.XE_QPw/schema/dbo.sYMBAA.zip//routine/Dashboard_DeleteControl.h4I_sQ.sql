CREATE PROCEDURE dbo.Dashboard_DeleteControl  
	@DashboardControlID int
AS
	DELETE dbo.Dashboard_Controls 
	WHERE DashboardControlID = @DashboardControlID
go

