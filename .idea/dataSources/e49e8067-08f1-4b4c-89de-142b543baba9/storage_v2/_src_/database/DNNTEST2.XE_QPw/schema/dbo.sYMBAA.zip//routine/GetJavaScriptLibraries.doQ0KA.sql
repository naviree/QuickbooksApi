CREATE PROCEDURE dbo.[GetJavaScriptLibraries]
AS
	SELECT * FROM dbo.JavaScriptLibraries
go

