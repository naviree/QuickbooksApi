CREATE PROCEDURE dbo.[DeleteUserRelationshipPreference]
	@PreferenceID INT	
AS 
	BEGIN
		DELETE FROM dbo.UserRelationshipPreferences  
		WHERE PreferenceID = @PreferenceID

	END
go

