CREATE PROCEDURE dbo.[CoreMessaging_GetMessageAttachment]
    @MessageAttachmentID INT
AS
	SELECT [MessageID], [FileID], [CreatedByUserID], [CreatedOnDate], [LastModifiedByUserID], [LastModifiedOnDate]
	FROM   dbo.CoreMessaging_MessageAttachments
	WHERE  [MessageAttachmentID] = @MessageAttachmentID
go

