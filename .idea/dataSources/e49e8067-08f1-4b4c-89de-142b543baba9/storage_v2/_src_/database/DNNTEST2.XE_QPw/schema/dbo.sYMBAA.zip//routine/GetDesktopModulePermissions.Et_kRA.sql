CREATE PROCEDURE dbo.[GetDesktopModulePermissions]
AS
    SELECT *
    FROM dbo.vw_DesktopModulePermissions
go

