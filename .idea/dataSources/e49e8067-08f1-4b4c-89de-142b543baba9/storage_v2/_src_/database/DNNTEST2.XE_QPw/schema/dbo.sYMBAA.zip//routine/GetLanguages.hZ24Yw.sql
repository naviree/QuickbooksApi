CREATE PROCEDURE dbo.[GetLanguages]
AS
	SELECT *
		FROM   dbo.Languages
go

