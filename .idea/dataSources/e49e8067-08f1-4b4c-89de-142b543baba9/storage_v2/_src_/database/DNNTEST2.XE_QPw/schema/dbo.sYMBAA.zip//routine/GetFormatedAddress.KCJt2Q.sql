CREATE FUNCTION dbo.[GetFormatedAddress]
(
	@locationId int
	,@addressType varchar(30)
)
RETURNS varchar(max)
AS
	BEGIN

		DECLARE @address varchar(max)

		SELECT @address = 
		CASE
			WHEN @addressType = 'Location'
			THEN
				CONCAT
					(
						LocationAddress1 + char(13)+char(10)
						,CASE
							WHEN LEN(LocationAddress2) > 0 
							THEN LocationAddress2 + char(13)+char(10)
							ELSE ''
						END
						,LocationCity
						,', ' + LocationState
						,' ' + LocationZip
					)
			WHEN @addressType = 'Billing'
			THEN
				CONCAT
					(
						LocationAddress1 + char(13)+char(10)
						,CASE
							WHEN LEN(LocationAddress2) > 0 
							THEN LocationAddress2 + char(13)+char(10)
							ELSE ''
						END
						,LocationCity
						,', ' + LocationState
						,' ' + LocationZip
					)
		END
			from JNGrease_Locations
			where LocationId = @locationId

		RETURN @address

	END
go

