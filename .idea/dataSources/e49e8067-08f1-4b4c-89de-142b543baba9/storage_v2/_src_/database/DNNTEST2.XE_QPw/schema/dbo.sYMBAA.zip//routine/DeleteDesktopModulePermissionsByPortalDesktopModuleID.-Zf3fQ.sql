CREATE PROCEDURE dbo.[DeleteDesktopModulePermissionsByPortalDesktopModuleID]
	@PortalDesktopModuleID int
AS
    DELETE FROM dbo.DesktopModulePermission
    WHERE PortalDesktopModuleID = @PortalDesktopModuleID
go

