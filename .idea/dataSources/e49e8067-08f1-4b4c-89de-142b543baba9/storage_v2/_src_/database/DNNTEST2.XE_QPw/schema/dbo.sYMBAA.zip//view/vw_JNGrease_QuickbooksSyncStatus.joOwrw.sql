


CREATE view [dbo].[vw_JNGrease_QuickbooksSyncStatus] as
	select 
		datediff(MINUTE,max(LastUpdateDate),GETDATE()) MinutesSinceLastSync
		,CASE
		   WHEN datediff(MINUTE,max(LastUpdateDate),GETDATE()) > 240
		   THEN 1
		   ELSE 0
		END IsOutOfSync
	from JNGrease_QuickBooksSyncLog


go

