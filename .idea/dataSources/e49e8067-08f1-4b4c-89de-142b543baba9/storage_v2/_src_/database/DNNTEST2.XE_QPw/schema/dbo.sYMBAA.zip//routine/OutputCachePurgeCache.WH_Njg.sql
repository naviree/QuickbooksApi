CREATE PROCEDURE dbo.[OutputCachePurgeCache]
AS
BEGIN
    DELETE
     FROM  dbo.OutputCache
END
go

