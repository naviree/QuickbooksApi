CREATE PROCEDURE dbo.[DeleteUserRelationship] @UserRelationshipID INT	
AS 
	BEGIN
		DELETE FROM dbo.UserRelationships  
			WHERE UserRelationshipID = @UserRelationshipID
	END
go

