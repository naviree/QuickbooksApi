CREATE PROCEDURE dbo.[DeletePermission]
	@PermissionID int
AS

DELETE FROM dbo.Permission
WHERE
	[PermissionID] = @PermissionID
go

