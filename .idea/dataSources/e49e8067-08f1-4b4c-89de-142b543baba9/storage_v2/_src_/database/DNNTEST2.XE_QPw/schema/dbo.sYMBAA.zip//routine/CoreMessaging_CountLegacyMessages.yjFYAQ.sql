CREATE PROCEDURE dbo.[CoreMessaging_CountLegacyMessages]    
AS
	--Return total records
	SELECT COUNT(*) AS TotalRecords
	FROM dbo.[Messaging_Messages]
go

