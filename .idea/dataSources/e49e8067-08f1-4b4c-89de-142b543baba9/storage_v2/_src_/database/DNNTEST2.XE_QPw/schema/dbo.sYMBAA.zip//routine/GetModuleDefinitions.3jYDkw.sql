CREATE PROCEDURE dbo.[GetModuleDefinitions]
AS
    SELECT *
    FROM   dbo.ModuleDefinitions
go

