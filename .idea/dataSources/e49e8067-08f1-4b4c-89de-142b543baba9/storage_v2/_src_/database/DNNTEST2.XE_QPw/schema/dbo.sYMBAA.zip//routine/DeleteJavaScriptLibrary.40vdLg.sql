CREATE PROCEDURE dbo.[DeleteJavaScriptLibrary]
	@JavaScriptLibraryID INT
AS
	DELETE FROM dbo.[JavaScriptLibraries]
	WHERE JavaScriptLibraryID = @JavaScriptLibraryID
go

