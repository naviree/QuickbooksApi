CREATE PROCEDURE dbo.[CoreMessaging_DeleteMessageRecipient]
    @RecipientID int
AS
	DELETE FROM dbo.CoreMessaging_MessageRecipients
	WHERE  [RecipientID] = @RecipientID
go

