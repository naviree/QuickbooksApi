CREATE PROCEDURE dbo.[SearchTypes_GetAll]
AS
    SELECT *
	FROM dbo.[SearchTypes]
go

