CREATE PROCEDURE dbo.[GetPortalGroups]

AS 
	SELECT * FROM dbo.PortalGroups
go

