CREATE PROCEDURE dbo.[GetDesktopModulePermissionsByPortalDesktopModuleID]
	@PortalDesktopModuleID int
AS
    SELECT *
    FROM dbo.vw_DesktopModulePermissions
	WHERE   PortalDesktopModuleID = @PortalDesktopModuleID
go

