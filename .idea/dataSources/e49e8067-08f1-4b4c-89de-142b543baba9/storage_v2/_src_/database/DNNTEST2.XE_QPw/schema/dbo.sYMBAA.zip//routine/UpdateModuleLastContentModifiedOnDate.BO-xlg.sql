CREATE PROCEDURE dbo.[UpdateModuleLastContentModifiedOnDate]
    @ModuleID	int
AS
    UPDATE dbo.Modules
        SET    LastContentModifiedOnDate = GETDATE()
    WHERE  ModuleID = @ModuleID
go

