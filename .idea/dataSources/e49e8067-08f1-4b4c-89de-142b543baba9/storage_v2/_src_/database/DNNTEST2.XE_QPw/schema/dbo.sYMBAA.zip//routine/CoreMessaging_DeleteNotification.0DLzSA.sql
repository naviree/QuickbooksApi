CREATE PROCEDURE dbo.[CoreMessaging_DeleteNotification]
	@NotificationID int
AS
BEGIN
	DELETE
	FROM dbo.[CoreMessaging_Messages]
	WHERE [MessageID] = @NotificationID AND [NotificationTypeID] IS NOT NULL
END
go

