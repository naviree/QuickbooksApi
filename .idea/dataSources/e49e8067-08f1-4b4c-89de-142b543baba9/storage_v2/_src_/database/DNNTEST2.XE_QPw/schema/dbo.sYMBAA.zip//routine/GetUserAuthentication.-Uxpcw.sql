CREATE PROCEDURE dbo.[GetUserAuthentication]
  @UserID          int

AS
  select * from dbo.UserAuthentication
     where UserId = @UserID
go

