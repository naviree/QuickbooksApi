CREATE PROCEDURE dbo.[GetUnIndexedContentItems] 
AS
	SELECT *
	FROM dbo.ContentItems
	WHERE Indexed = 0
go

