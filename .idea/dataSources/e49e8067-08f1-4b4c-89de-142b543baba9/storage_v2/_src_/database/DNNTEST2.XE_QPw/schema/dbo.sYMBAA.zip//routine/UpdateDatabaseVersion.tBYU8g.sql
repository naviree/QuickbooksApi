create procedure dbo.[UpdateDatabaseVersion]

@Major  int,
@Minor  int,
@Build  int

as

insert into dbo.Version (
  Major,
  Minor,
  Build,
  CreatedDate
)
values (
  @Major,
  @Minor,
  @Build,
  getdate()
)
go

