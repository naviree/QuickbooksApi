CREATE PROCEDURE dbo.[GetRoleGroupByName]
	@PortalID		int,
	@RoleGroupName	nvarchar(50)
AS
	SELECT *
		FROM dbo.RoleGroups
		WHERE  PortalId = @PortalID 
			AND RoleGroupName = @RoleGroupName
go

