CREATE PROCEDURE dbo.[GetSkinControl]
	@SkinControlID	int
AS
    SELECT *
    FROM   dbo.SkinControls
	WHERE SkinControlID = @SkinControlID
go

