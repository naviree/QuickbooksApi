CREATE PROCEDURE dbo.[Journal_TypeFilters_Delete]
@PortalId int,
@ModuleId int
AS
DELETE FROM dbo.[Journal_TypeFilters] WHERE PortalId = @PortalId AND ModuleId=@ModuleId
go

