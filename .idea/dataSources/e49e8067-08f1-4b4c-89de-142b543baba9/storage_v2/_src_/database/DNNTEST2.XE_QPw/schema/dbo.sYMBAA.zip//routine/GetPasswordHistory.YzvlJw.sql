CREATE PROCEDURE dbo.[GetPasswordHistory]
    @UserID			int
AS
        SELECT * from dbo.PasswordHistory where UserID=@UserID
go

