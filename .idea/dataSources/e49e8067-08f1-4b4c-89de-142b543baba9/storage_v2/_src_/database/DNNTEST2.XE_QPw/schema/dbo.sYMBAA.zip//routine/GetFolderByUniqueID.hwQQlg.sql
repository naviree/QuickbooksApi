CREATE PROCEDURE dbo.[GetFolderByUniqueID]
    @UniqueID   uniqueidentifier
AS
	SELECT	* 
	FROM	dbo.Folders
	WHERE	UniqueID = @UniqueID
go

