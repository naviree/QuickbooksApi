CREATE PROCEDURE [dbo].[JNGrease_GetCalendarDates]
		@StartDate datetime, 
		@EndDate datetime
	AS
	BEGIN

		SET NOCOUNT ON;

		SELECT
			sd.ServiceStartDate start
			,sd.ServiceStartDate [end]
			,l.LocationName +CHAR(10)+CHAR(13) + s.ServiceDescription title
			,CONCAT('Every ',sd.ServiceCount, ' ',  sd.ServiceInterval,'(s)') [description]
			,l.LocationId id
			,0 [AllDay]
			,CASE
				WHEN l.MaxInvoiceAging > 1
					THEN '#FCC'
				ELSE '#d9edf7'
			END AS color
			,CASE
				WHEN l.MaxInvoiceAging > 1
					THEN '#000000'
				ELSE '#000000'
			END AS textColor
			,CASE
				WHEN l.MaxInvoiceAging > 1
					THEN '#C00'
				ELSE '#31708f'
			END AS borderColor
		FROM dbo.GetServiceDates(@EndDate) sd
		JOIN JNGrease_Locations l
			ON sd.LocationId = l.LocationId
		JOIN JNGrease_Services s
			on sd.ServiceId = s.ServiceId 
		where sd.ServiceStartDate between @StartDate and @EndDate
		option (maxrecursion 0)
	END
go

