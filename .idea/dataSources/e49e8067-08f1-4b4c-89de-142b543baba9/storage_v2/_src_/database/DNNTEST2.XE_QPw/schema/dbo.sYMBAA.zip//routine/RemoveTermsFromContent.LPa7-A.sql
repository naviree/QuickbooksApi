CREATE PROCEDURE dbo.[RemoveTermsFromContent] 
	@ContentItemID	int
AS
	DELETE dbo.ContentItems_Tags 
	WHERE ContentItemID = @ContentItemID
go

