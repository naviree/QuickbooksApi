CREATE PROCEDURE dbo.[GetAllTabs] 
AS
	SELECT *
		FROM dbo.vw_Tabs
		ORDER BY Level, ParentID, TabOrder
go

