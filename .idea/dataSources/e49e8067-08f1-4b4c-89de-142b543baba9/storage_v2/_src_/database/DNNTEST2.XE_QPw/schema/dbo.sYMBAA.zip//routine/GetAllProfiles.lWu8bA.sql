create procedure dbo.[GetAllProfiles]
AS
SELECT * FROM dbo.Profile
go

