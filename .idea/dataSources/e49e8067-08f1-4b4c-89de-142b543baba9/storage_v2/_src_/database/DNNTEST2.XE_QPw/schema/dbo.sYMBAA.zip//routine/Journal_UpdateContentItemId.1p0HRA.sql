CREATE PROCEDURE dbo.[Journal_UpdateContentItemId]
@JournalId int,
@ContentItemId int
AS
UPDATE dbo.[Journal]
	SET ContentItemId = @ContentItemId
WHERE JournalId = @JournalId
go

