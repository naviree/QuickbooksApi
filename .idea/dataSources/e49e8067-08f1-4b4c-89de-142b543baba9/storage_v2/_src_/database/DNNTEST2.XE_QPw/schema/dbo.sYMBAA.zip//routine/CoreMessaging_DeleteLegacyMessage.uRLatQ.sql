CREATE PROCEDURE dbo.[CoreMessaging_DeleteLegacyMessage]
    @MessageID int
AS
	DELETE FROM dbo.Messaging_Messages
	WHERE  [MessageID] = @MessageID
go

