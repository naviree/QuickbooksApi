CREATE PROCEDURE dbo.[DeletePortalGroup]
	@PortalGroupID	int
AS 
	BEGIN
		DELETE FROM dbo.PortalGroups  
			WHERE PortalGroupID = @PortalGroupID
	END
go

