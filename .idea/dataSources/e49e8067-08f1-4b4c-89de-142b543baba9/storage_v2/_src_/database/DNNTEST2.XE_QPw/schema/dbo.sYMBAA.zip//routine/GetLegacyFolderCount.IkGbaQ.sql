CREATE PROCEDURE dbo.[GetLegacyFolderCount]
AS
	SELECT COUNT(*)
	FROM dbo.Folders
		WHERE ParentID IS NULL AND FolderPath <> ''
go

