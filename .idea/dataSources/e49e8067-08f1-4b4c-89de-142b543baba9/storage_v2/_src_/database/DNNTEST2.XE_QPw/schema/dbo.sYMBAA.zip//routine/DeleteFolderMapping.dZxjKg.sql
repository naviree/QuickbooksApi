CREATE PROCEDURE dbo.[DeleteFolderMapping]
	@FolderMappingID int
AS
BEGIN
	DELETE
	FROM dbo.[FolderMappings]
	WHERE FolderMappingID = @FolderMappingID
END
go

