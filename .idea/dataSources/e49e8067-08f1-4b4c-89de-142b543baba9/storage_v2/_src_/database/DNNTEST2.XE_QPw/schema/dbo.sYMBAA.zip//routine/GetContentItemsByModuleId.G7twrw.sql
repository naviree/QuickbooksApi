CREATE PROCEDURE dbo.[GetContentItemsByModuleId] 
	@ModuleId int
AS
	SELECT * FROM dbo.ContentItems WHERE ModuleID = @ModuleId
go

